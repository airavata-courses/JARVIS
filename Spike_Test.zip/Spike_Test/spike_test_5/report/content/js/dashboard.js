/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.36034115138592, "KoPercent": 0.6396588486140725};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9408315565031983, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "HIstory Page"], "isController": false}, {"data": [0.95, 500, 1500, "History Details"], "isController": false}, {"data": [0.9583333333333334, 500, 1500, "Visit Login"], "isController": false}, {"data": [1.0, 500, 1500, "Registration Signup"], "isController": false}, {"data": [1.0, 500, 1500, "Add user history "], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "S3  Weather Details"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Login"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-0"], "isController": false}, {"data": [1.0, 500, 1500, "Verify Token"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-5"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "Login Page"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-6"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-7"], "isController": false}, {"data": [0.0, 500, 1500, "Get S3 Weather "], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-8"], "isController": false}, {"data": [1.0, 500, 1500, "Add user Db Details"], "isController": false}, {"data": [0.9791666666666666, 500, 1500, "Visit Login-1"], "isController": false}, {"data": [0.9895833333333334, 500, 1500, "Visit Login-2"], "isController": false}, {"data": [1.0, 500, 1500, "Stored Image"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-3"], "isController": false}, {"data": [0.9791666666666666, 500, 1500, "Visit Login-4"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 938, 6, 0.6396588486140725, 283.2089552238809, 0, 8040, 13.0, 218.10000000000002, 2593.149999999995, 5849.530000000001, 6.293527998819124, 322.10691606644434, 5.321643815166195], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HIstory Page", 10, 0, 0.0, 66.10000000000001, 44, 154, 54.5, 146.50000000000003, 154.0, 154.0, 0.08530458000290035, 40.98476873395207, 0.3118948706356044], "isController": false}, {"data": ["History Details", 10, 0, 0.0, 93.1, 20, 510, 41.0, 470.3000000000001, 510.0, 510.0, 0.08532059212490935, 0.014331193208480867, 0.06057428757305576], "isController": false}, {"data": ["Visit Login", 48, 0, 0.0, 232.4791666666666, 137, 1008, 177.5, 335.30000000000047, 693.5999999999998, 1008.0, 0.408250053157559, 93.28755415426323, 1.8578566872209228], "isController": false}, {"data": ["Registration Signup", 28, 0, 0.0, 9.357142857142858, 4, 47, 6.0, 20.300000000000004, 36.19999999999993, 47.0, 0.21532498692669721, 0.05908820442031437, 0.11018583315389584], "isController": false}, {"data": ["Add user history ", 10, 0, 0.0, 31.5, 8, 120, 17.0, 115.40000000000002, 120.0, 120.0, 0.08542408788430161, 0.018686519224690976, 0.05305636708439045], "isController": false}, {"data": ["Base Page-0", 6, 0, 0.0, 10.0, 2, 19, 9.0, 19.0, 19.0, 19.0, 0.05232953653473809, 0.1197344766610267, 0.024887191691813915], "isController": false}, {"data": ["Base Page-1", 6, 0, 0.0, 46.833333333333336, 42, 55, 46.0, 55.0, 55.0, 55.0, 0.052311287032031945, 0.04250292071352596, 0.030038121850424596], "isController": false}, {"data": ["Base Page-2", 6, 0, 0.0, 8.333333333333334, 1, 13, 10.0, 13.0, 13.0, 13.0, 0.052330449344125035, 0.06970579385291654, 0.02534756140106056], "isController": false}, {"data": ["Base Page-3", 6, 0, 0.0, 69.16666666666667, 60, 79, 68.0, 79.0, 79.0, 79.0, 0.05230034343892192, 4.776288004916233, 0.026916290031554543], "isController": false}, {"data": ["Base Page-4", 6, 0, 0.0, 7.333333333333334, 1, 13, 7.5, 13.0, 13.0, 13.0, 0.052330449344125035, 0.00919871179877198, 0.029538085664945576], "isController": false}, {"data": ["Base Page-5", 6, 0, 0.0, 4.333333333333333, 1, 12, 2.0, 12.0, 12.0, 12.0, 0.05233592686926486, 0.009148565341404695, 0.029490068167544747], "isController": false}, {"data": ["Base Page-6", 6, 0, 0.0, 5.833333333333334, 1, 13, 3.0, 13.0, 13.0, 13.0, 0.052330449344125035, 0.042620698000976835, 0.02529645744662294], "isController": false}, {"data": ["S3  Weather Details", 28, 0, 0.0, 10.107142857142856, 4, 32, 8.0, 19.80000000000001, 29.749999999999986, 32.0, 0.21532167520263307, 0.04373721527553484, 0.17074335963333792], "isController": false}, {"data": ["HIstory Page-6", 10, 0, 0.0, 35.2, 28, 48, 34.0, 47.6, 48.0, 48.0, 0.08532423208191127, 0.017914755759385666, 0.048078204991467574], "isController": false}, {"data": ["Home Page", 28, 0, 0.0, 210.42857142857142, 168, 312, 198.0, 289.90000000000003, 309.75, 312.0, 0.214987714987715, 54.42905285434582, 0.5454473472051596], "isController": false}, {"data": ["Base Page", 6, 0, 0.0, 80.33333333333333, 65, 99, 79.5, 99.0, 99.0, 99.0, 0.05229305025362129, 5.068340480050201, 0.19140073471735605], "isController": false}, {"data": ["HIstory Page-3", 10, 0, 0.0, 60.3, 40, 149, 51.0, 140.50000000000003, 149.0, 149.0, 0.08531258531258532, 13.73116058174652, 0.044489180231367734], "isController": false}, {"data": ["HIstory Page-2", 10, 0, 0.0, 2.3000000000000003, 1, 4, 2.0, 3.9000000000000004, 4.0, 4.0, 0.0853577342643017, 0.015004289226146782, 0.048180439848404664], "isController": false}, {"data": ["HIstory Page-5", 10, 0, 0.0, 6.3, 4, 16, 5.0, 15.300000000000002, 16.0, 16.0, 0.08535627710061798, 13.859975561430913, 0.043595051683225784], "isController": false}, {"data": ["HIstory Page-4", 10, 0, 0.0, 6.0, 3, 20, 5.0, 18.600000000000005, 20.0, 20.0, 0.0853446215819479, 12.887704613730243, 0.043422410004096544], "isController": false}, {"data": ["Home Page-3", 28, 0, 0.0, 2.321428571428571, 1, 12, 2.0, 3.0, 7.949999999999974, 12.0, 0.21527366664872719, 0.03784107421559658, 0.12151189387008234], "isController": false}, {"data": ["Home Page-4", 28, 0, 0.0, 4.785714285714285, 3, 15, 4.0, 6.300000000000004, 12.299999999999983, 15.0, 0.21527035650308685, 32.183759197041574, 0.10553292867631796], "isController": false}, {"data": ["Home Page-1", 28, 0, 0.0, 2.892857142857143, 1, 14, 1.5, 7.500000000000007, 13.099999999999994, 14.0, 0.21527366664872719, 1.7465758032398686, 0.10406295409289058], "isController": false}, {"data": ["HIstory Page-1", 10, 0, 0.0, 5.199999999999999, 1, 19, 2.0, 18.6, 19.0, 19.0, 0.0853453499586075, 0.34271492092753325, 0.04217260456939004], "isController": false}, {"data": ["Home Page-2", 28, 0, 0.0, 204.92857142857144, 164, 309, 195.5, 271.70000000000005, 299.0999999999999, 309.0, 0.2149943180073098, 19.008311114054486, 0.11064648983384011], "isController": false}, {"data": ["HIstory Page-0", 10, 0, 0.0, 4.9, 2, 15, 3.5, 14.400000000000002, 15.0, 15.0, 0.0853511774194925, 0.14628058239375913, 0.04209213339535519], "isController": false}, {"data": ["Home Page-0", 28, 0, 0.0, 4.5357142857142865, 2, 19, 2.0, 17.200000000000003, 19.0, 19.0, 0.21527035650308685, 1.4997448469658414, 0.10427157893118269], "isController": false}, {"data": ["Login", 6, 0, 0.0, 20.166666666666664, 6, 39, 14.0, 39.0, 39.0, 39.0, 0.05178172277791682, 0.029784604215032234, 0.026447110364111816], "isController": false}, {"data": ["Visit Login-0", 48, 0, 0.0, 15.000000000000002, 0, 483, 2.0, 14.0, 46.99999999999983, 483.0, 0.4088342262386399, 1.8042205745824356, 0.20082384355276944], "isController": false}, {"data": ["Verify Token", 6, 0, 0.0, 22.5, 4, 93, 7.5, 93.0, 93.0, 93.0, 0.05179736869367036, 0.014365676473635139, 0.040011443981145756], "isController": false}, {"data": ["Visit Login-5", 48, 0, 0.0, 164.89583333333331, 132, 226, 158.5, 211.70000000000002, 222.29999999999998, 226.0, 0.40839941462750573, 37.29675747881428, 0.21018212061396047], "isController": false}, {"data": ["Login Page", 6, 0, 0.0, 206.66666666666669, 1, 1226, 2.5, 1226.0, 1226.0, 1226.0, 0.051796474386643414, 0.00915543150779537, 0.029590759293150783], "isController": false}, {"data": ["Visit Login-6", 48, 0, 0.0, 6.020833333333331, 1, 30, 2.0, 24.0, 25.0, 30.0, 0.40897704616328406, 0.5343860232094474, 0.19849764838198455], "isController": false}, {"data": ["Visit Login-7", 48, 0, 0.0, 5.416666666666668, 1, 27, 2.0, 21.0, 24.19999999999999, 27.0, 0.4089840155413926, 0.1290057002147166, 0.19850103098053917], "isController": false}, {"data": ["Get S3 Weather ", 50, 6, 12.0, 4019.399999999999, 2292, 8040, 3537.5, 6248.0, 6718.999999999999, 8040.0, 0.3354759061204224, 0.08926804189423115, 0.17789396193690368], "isController": false}, {"data": ["Visit Login-8", 48, 0, 0.0, 2.7083333333333344, 1, 10, 2.0, 5.100000000000001, 7.099999999999994, 10.0, 0.40899447005393613, 2.3924578863506616, 0.20010373974318554], "isController": false}, {"data": ["Add user Db Details", 10, 0, 0.0, 14.2, 6, 56, 9.5, 51.80000000000001, 56.0, 56.0, 0.08539563799081143, 0.018513507455039196, 0.04745128712575362], "isController": false}, {"data": ["Visit Login-1", 48, 0, 0.0, 171.39583333333337, 107, 991, 136.5, 189.3, 506.1999999999989, 991.0, 0.408576706020548, 9.880479010967731, 0.214662370936577], "isController": false}, {"data": ["Visit Login-2", 48, 0, 0.0, 180.60416666666663, 123, 683, 166.0, 211.70000000000002, 264.3999999999998, 683.0, 0.40840983927371116, 5.151787005760281, 0.22175377991814788], "isController": false}, {"data": ["Stored Image", 8, 0, 0.0, 18.125, 3, 120, 4.0, 120.0, 120.0, 120.0, 0.06910551548395456, 9.34841057314387, 0.035497559711484473], "isController": false}, {"data": ["Visit Login-3", 48, 0, 0.0, 3.645833333333334, 1, 32, 2.0, 5.0, 16.999999999999943, 32.0, 0.40897356156330145, 4.61812626206685, 0.2004928983445091], "isController": false}, {"data": ["Visit Login-4", 48, 0, 0.0, 172.27083333333331, 108, 667, 145.0, 210.30000000000013, 465.54999999999916, 667.0, 0.4086045304027308, 31.547541775556937, 0.2150760174678437], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 6, 100.0, 0.6396588486140725], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 938, 6, "502/Bad Gateway", 6, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Get S3 Weather ", 50, 6, "502/Bad Gateway", 6, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
