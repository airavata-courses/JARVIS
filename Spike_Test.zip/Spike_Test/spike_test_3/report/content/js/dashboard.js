/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.67256637168141, "KoPercent": 1.3274336283185841};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9347345132743363, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9615384615384616, 500, 1500, "HIstory Page"], "isController": false}, {"data": [1.0, 500, 1500, "History Details"], "isController": false}, {"data": [0.9186046511627907, 500, 1500, "Visit Login"], "isController": false}, {"data": [1.0, 500, 1500, "Registration Signup"], "isController": false}, {"data": [1.0, 500, 1500, "Add user history "], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "S3  Weather Details"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-2"], "isController": false}, {"data": [0.9615384615384616, 500, 1500, "HIstory Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Login"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-0"], "isController": false}, {"data": [1.0, 500, 1500, "Verify Token"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-5"], "isController": false}, {"data": [1.0, 500, 1500, "Login Page"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-6"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-7"], "isController": false}, {"data": [0.0, 500, 1500, "Get S3 Weather "], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-8"], "isController": false}, {"data": [1.0, 500, 1500, "Add user Db Details"], "isController": false}, {"data": [0.9534883720930233, 500, 1500, "Visit Login-1"], "isController": false}, {"data": [0.9767441860465116, 500, 1500, "Visit Login-2"], "isController": false}, {"data": [1.0, 500, 1500, "Stored Image"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-3"], "isController": false}, {"data": [0.9418604651162791, 500, 1500, "Visit Login-4"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 904, 12, 1.3274336283185841, 330.6327433628318, 0, 14687, 16.0, 302.5, 2660.5, 7161.750000000056, 6.213058419243986, 329.9030551975945, 5.23461662371134], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HIstory Page", 13, 0, 0.0, 158.15384615384613, 49, 1182, 61.0, 785.1999999999996, 1182.0, 1182.0, 0.11036309458117205, 53.02418589973512, 0.4035150645624103], "isController": false}, {"data": ["History Details", 13, 0, 0.0, 28.46153846153846, 10, 121, 23.0, 84.59999999999997, 121.0, 121.0, 0.11062323428299126, 0.018581246383471185, 0.07853817512083461], "isController": false}, {"data": ["Visit Login", 43, 0, 0.0, 294.90697674418607, 139, 903, 195.0, 672.6, 678.2, 903.0, 0.4087297060948253, 93.39724413401582, 1.8600394828143418], "isController": false}, {"data": ["Registration Signup", 26, 0, 0.0, 8.0, 4, 65, 5.0, 15.500000000000004, 48.899999999999935, 65.0, 0.21912820685702727, 0.06013186145197721, 0.11213201210261943], "isController": false}, {"data": ["Add user history ", 13, 0, 0.0, 20.615384615384617, 6, 117, 8.0, 94.59999999999998, 117.0, 117.0, 0.11061758649444359, 0.024197597045659536, 0.06870389161178332], "isController": false}, {"data": ["Base Page-0", 6, 0, 0.0, 3.0, 2, 4, 3.0, 4.0, 4.0, 4.0, 0.08665761576013171, 0.19828007199803577, 0.04121314343279702], "isController": false}, {"data": ["Base Page-1", 6, 0, 0.0, 44.833333333333336, 31, 63, 39.5, 63.0, 63.0, 63.0, 0.0866225853954321, 0.07038085063378857, 0.04974031270753328], "isController": false}, {"data": ["Base Page-2", 6, 0, 0.0, 2.166666666666667, 1, 3, 2.0, 3.0, 3.0, 3.0, 0.0866588673686035, 0.11543231942458512, 0.04197538888166732], "isController": false}, {"data": ["Base Page-3", 6, 0, 0.0, 71.33333333333333, 58, 105, 62.5, 105.0, 105.0, 105.0, 0.08658133595001372, 7.90697286396629, 0.04455894926333713], "isController": false}, {"data": ["Base Page-4", 6, 0, 0.0, 2.0, 1, 3, 2.0, 3.0, 3.0, 3.0, 0.0866588673686035, 0.015233004029637334, 0.048914868495168774], "isController": false}, {"data": ["Base Page-5", 6, 0, 0.0, 1.8333333333333335, 1, 2, 2.0, 2.0, 2.0, 2.0, 0.0866588673686035, 0.015148376229472682, 0.04883024069500412], "isController": false}, {"data": ["Base Page-6", 6, 0, 0.0, 1.8333333333333333, 1, 3, 1.5, 3.0, 3.0, 3.0, 0.0866601190132301, 0.07058060474319718, 0.04189136612455947], "isController": false}, {"data": ["S3  Weather Details", 26, 0, 0.0, 8.538461538461537, 3, 29, 5.5, 21.100000000000005, 27.949999999999996, 29.0, 0.21912266655429605, 0.04450929164384139, 0.17375742699422697], "isController": false}, {"data": ["HIstory Page-6", 13, 0, 0.0, 36.23076923076923, 27, 60, 34.0, 56.0, 60.0, 60.0, 0.11038464804279528, 0.02317646418867284, 0.06219916203192664], "isController": false}, {"data": ["Home Page", 26, 0, 0.0, 202.46153846153848, 173, 276, 195.5, 236.20000000000002, 265.49999999999994, 276.0, 0.2188018076395493, 55.39489124077456, 0.555124117429247], "isController": false}, {"data": ["Base Page", 6, 0, 0.0, 75.16666666666666, 61, 108, 66.5, 108.0, 108.0, 108.0, 0.08657633868663694, 8.39114107614389, 0.316882927146011], "isController": false}, {"data": ["HIstory Page-3", 13, 0, 0.0, 69.92307692307692, 46, 185, 57.0, 154.99999999999997, 185.0, 185.0, 0.11036777940027848, 17.763823431716304, 0.057555072460692094], "isController": false}, {"data": ["HIstory Page-2", 13, 0, 0.0, 8.076923076923078, 1, 77, 2.0, 48.59999999999997, 77.0, 77.0, 0.11042027656032345, 0.019409814239119357, 0.06232707016783882], "isController": false}, {"data": ["HIstory Page-5", 13, 0, 0.0, 11.384615384615387, 4, 72, 6.0, 49.59999999999998, 72.0, 72.0, 0.110406209924669, 17.927531792211266, 0.056389109170509655], "isController": false}, {"data": ["HIstory Page-4", 13, 0, 0.0, 9.076923076923075, 2, 48, 5.0, 35.59999999999999, 48.0, 48.0, 0.11040527227638686, 16.672058654924076, 0.05617299497656011], "isController": false}, {"data": ["Home Page-3", 26, 0, 0.0, 2.115384615384615, 0, 4, 2.0, 3.0, 3.6499999999999986, 4.0, 0.21918547306126232, 0.03852869643655002, 0.12371992522403284], "isController": false}, {"data": ["Home Page-4", 26, 0, 0.0, 4.115384615384617, 2, 7, 4.0, 5.300000000000001, 6.649999999999999, 7.0, 0.21917992986242246, 32.76825568603318, 0.1074495359286485], "isController": false}, {"data": ["Home Page-1", 26, 0, 0.0, 2.5384615384615383, 1, 14, 2.0, 3.3000000000000007, 10.499999999999986, 14.0, 0.2191836252971624, 1.7782983974304936, 0.10595302199423379], "isController": false}, {"data": ["HIstory Page-1", 13, 0, 0.0, 10.000000000000002, 1, 103, 2.0, 62.999999999999964, 103.0, 103.0, 0.1104193386730993, 0.44340265685916436, 0.054562681024011954], "isController": false}, {"data": ["Home Page-2", 26, 0, 0.0, 197.96153846153848, 169, 272, 192.0, 232.9, 261.49999999999994, 272.0, 0.2188091731537976, 19.345807910793184, 0.11260979907426888], "isController": false}, {"data": ["HIstory Page-0", 13, 0, 0.0, 85.92307692307693, 2, 1078, 3.0, 649.9999999999997, 1078.0, 1078.0, 0.11041746294644753, 0.1892408666709135, 0.054453924597613286], "isController": false}, {"data": ["Home Page-0", 26, 0, 0.0, 3.6538461538461537, 2, 18, 3.0, 5.900000000000002, 14.499999999999986, 18.0, 0.21918177756421606, 1.5269949229913253, 0.10616617350766715], "isController": false}, {"data": ["Login", 5, 0, 0.0, 24.2, 8, 41, 29.0, 41.0, 41.0, 41.0, 0.07254682897810537, 0.04172859596494537, 0.03705272612846592], "isController": false}, {"data": ["Visit Login-0", 43, 0, 0.0, 6.162790697674418, 0, 21, 1.0, 19.0, 20.0, 21.0, 0.40931330553810424, 1.8063347927018485, 0.2010591725445961], "isController": false}, {"data": ["Verify Token", 5, 0, 0.0, 15.2, 3, 54, 4.0, 54.0, 54.0, 54.0, 0.07255419798589546, 0.020122453347650695, 0.05604528379574542], "isController": false}, {"data": ["Visit Login-5", 43, 0, 0.0, 187.44186046511635, 137, 294, 167.0, 242.0, 285.2, 294.0, 0.4089162767697516, 37.34395951015634, 0.2104481229078702], "isController": false}, {"data": ["Login Page", 5, 0, 0.0, 2.4, 2, 3, 2.0, 3.0, 3.0, 3.0, 0.07255525082350209, 0.012824707420951055, 0.04145002122241087], "isController": false}, {"data": ["Visit Login-6", 43, 0, 0.0, 21.02325581395349, 1, 109, 3.0, 94.4, 97.0, 109.0, 0.4094926100868505, 0.5350596799767637, 0.19874787813785616], "isController": false}, {"data": ["Visit Login-7", 43, 0, 0.0, 15.488372093023255, 1, 116, 2.0, 73.2, 88.99999999999997, 116.0, 0.40951210917783304, 0.12917227662542974, 0.19875734205213183], "isController": false}, {"data": ["Get S3 Weather ", 49, 12, 24.489795918367346, 4631.2857142857165, 1836, 14687, 3384.0, 8337.0, 13517.0, 14687.0, 0.4095243666998187, 0.13414665360088926, 0.21715989366992336], "isController": false}, {"data": ["Visit Login-8", 43, 0, 0.0, 21.13953488372093, 1, 112, 2.0, 94.40000000000003, 110.79999999999998, 112.0, 0.40952380952380957, 2.3955543154761907, 0.20036272321428572], "isController": false}, {"data": ["Add user Db Details", 13, 0, 0.0, 9.923076923076923, 4, 50, 6.0, 33.999999999999986, 50.0, 50.0, 0.11062699979576554, 0.023983587846347607, 0.06147144812870175], "isController": false}, {"data": ["Visit Login-1", 43, 0, 0.0, 220.62790697674419, 113, 712, 148.0, 511.0000000000002, 652.3999999999999, 712.0, 0.40905631659056313, 9.892163791975836, 0.21491435383371385], "isController": false}, {"data": ["Visit Login-2", 43, 0, 0.0, 222.4186046511627, 121, 705, 188.0, 316.40000000000003, 596.599999999999, 705.0, 0.40902907911383374, 5.159598256751358, 0.22209000780008942], "isController": false}, {"data": ["Stored Image", 11, 0, 0.0, 3.272727272727273, 2, 5, 3.0, 4.800000000000001, 5.0, 5.0, 0.13130252100840337, 17.762256269695378, 0.06744641215861345], "isController": false}, {"data": ["Visit Login-3", 43, 0, 0.0, 8.116279069767447, 1, 110, 3.0, 20.200000000000003, 23.799999999999997, 110.0, 0.40949650975649243, 4.62403138897883, 0.20074926552515546], "isController": false}, {"data": ["Visit Login-4", 43, 0, 0.0, 247.23255813953483, 116, 855, 148.0, 642.6, 670.1999999999999, 855.0, 0.40896294605493416, 31.575214334032374, 0.21526467570664992], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 12, 100.0, 1.3274336283185841], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 904, 12, "502/Bad Gateway", 12, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Get S3 Weather ", 49, 12, "502/Bad Gateway", 12, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
