/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.69183359013867, "KoPercent": 0.3081664098613251};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9244992295839753, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "HIstory Page"], "isController": false}, {"data": [1.0, 500, 1500, "History Details"], "isController": false}, {"data": [0.9814814814814815, 500, 1500, "Visit Login"], "isController": false}, {"data": [1.0, 500, 1500, "Registration Signup"], "isController": false}, {"data": [1.0, 500, 1500, "Add user history "], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "S3  Weather Details"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Login"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-0"], "isController": false}, {"data": [1.0, 500, 1500, "Verify Token"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-5"], "isController": false}, {"data": [1.0, 500, 1500, "Login Page"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-6"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-7"], "isController": false}, {"data": [0.0, 500, 1500, "Get S3 Weather "], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-8"], "isController": false}, {"data": [1.0, 500, 1500, "Add user Db Details"], "isController": false}, {"data": [0.9814814814814815, 500, 1500, "Visit Login-1"], "isController": false}, {"data": [0.9814814814814815, 500, 1500, "Visit Login-2"], "isController": false}, {"data": [1.0, 500, 1500, "Stored Image"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-3"], "isController": false}, {"data": [0.9814814814814815, 500, 1500, "Visit Login-4"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 649, 2, 0.3081664098613251, 701.932203389831, 1, 20838, 5.0, 229.0, 6430.0, 13827.5, 4.274517552525852, 228.9578020545182, 3.5168342060198903], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HIstory Page", 9, 0, 0.0, 50.77777777777778, 45, 59, 49.0, 59.0, 59.0, 59.0, 0.08540033780578066, 41.03077577607557, 0.3097430220807318], "isController": false}, {"data": ["History Details", 9, 0, 0.0, 19.111111111111107, 10, 73, 12.0, 73.0, 73.0, 73.0, 0.08553669524225893, 0.014367491778973179, 0.06022652077116083], "isController": false}, {"data": ["Visit Login", 27, 0, 0.0, 220.2222222222222, 150, 820, 170.0, 387.4, 649.1999999999991, 820.0, 0.25000231483624846, 57.127292194256434, 1.1303815602459282], "isController": false}, {"data": ["Registration Signup", 24, 0, 0.0, 8.291666666666664, 4, 78, 5.0, 7.0, 60.25, 78.0, 0.20438577815626996, 0.058647807110921865, 0.10339046199701937], "isController": false}, {"data": ["Add user history ", 9, 0, 0.0, 9.444444444444445, 6, 20, 7.0, 20.0, 20.0, 20.0, 0.0855228773696964, 0.01865245046800019, 0.052616614006746804], "isController": false}, {"data": ["Base Page-0", 3, 0, 0.0, 7.333333333333333, 1, 19, 2.0, 19.0, 19.0, 19.0, 0.0360304096657579, 0.08244067367858472, 0.01692444047776323], "isController": false}, {"data": ["Base Page-1", 3, 0, 0.0, 47.333333333333336, 44, 51, 47.0, 51.0, 51.0, 51.0, 0.03600965058635715, 0.029257841101415178, 0.020677416547634764], "isController": false}, {"data": ["Base Page-2", 3, 0, 0.0, 6.0, 2, 13, 3.0, 13.0, 13.0, 13.0, 0.03602608288400802, 0.04798786821658881, 0.0172390435675429], "isController": false}, {"data": ["Base Page-3", 3, 0, 0.0, 60.666666666666664, 52, 72, 58.0, 72.0, 72.0, 72.0, 0.03600057600921615, 3.2877244785916577, 0.018527640192243077], "isController": false}, {"data": ["Base Page-4", 3, 0, 0.0, 5.0, 1, 13, 1.0, 13.0, 13.0, 13.0, 0.03602608288400802, 0.006332709881954535, 0.020123944735988858], "isController": false}, {"data": ["Base Page-5", 3, 0, 0.0, 2.0, 1, 3, 2.0, 3.0, 3.0, 3.0, 0.03603127514682745, 0.006298435792267689, 0.02009165830941257], "isController": false}, {"data": ["Base Page-6", 3, 0, 0.0, 6.0, 2, 13, 3.0, 13.0, 13.0, 13.0, 0.03602608288400802, 0.029341555786389348, 0.017203861845976488], "isController": false}, {"data": ["S3  Weather Details", 24, 0, 0.0, 4.25, 3, 8, 4.0, 5.5, 7.5, 8.0, 0.2045181467247271, 0.04154274855346019, 0.16097815064465823], "isController": false}, {"data": ["HIstory Page-6", 9, 0, 0.0, 32.0, 26, 53, 29.0, 53.0, 53.0, 53.0, 0.08542384464250122, 0.017935670505993907, 0.04813433433469062], "isController": false}, {"data": ["Home Page", 24, 0, 0.0, 195.91666666666669, 167, 234, 190.5, 228.5, 232.75, 234.0, 0.2039949001274968, 51.64597056948576, 0.5127762430939227], "isController": false}, {"data": ["Base Page", 3, 0, 0.0, 68.66666666666667, 55, 91, 60.0, 91.0, 91.0, 91.0, 0.03599928001439971, 3.489117717645647, 0.13070832333353333], "isController": false}, {"data": ["HIstory Page-3", 9, 0, 0.0, 47.111111111111114, 42, 55, 46.0, 55.0, 55.0, 55.0, 0.0854035793589038, 13.745806180135126, 0.04453663220474085], "isController": false}, {"data": ["HIstory Page-2", 9, 0, 0.0, 1.8888888888888888, 1, 3, 2.0, 3.0, 3.0, 3.0, 0.08544330836489988, 0.015019331548517558, 0.047728098031955796], "isController": false}, {"data": ["HIstory Page-5", 9, 0, 0.0, 4.666666666666667, 4, 5, 5.0, 5.0, 5.0, 5.0, 0.08544168604927137, 13.873844089690037, 0.043138038757298144], "isController": false}, {"data": ["HIstory Page-4", 9, 0, 0.0, 5.0, 4, 6, 5.0, 6.0, 6.0, 6.0, 0.08544087491455914, 12.902239618933699, 0.04297075252050581], "isController": false}, {"data": ["Home Page-3", 24, 0, 0.0, 1.958333333333333, 1, 3, 2.0, 3.0, 3.0, 3.0, 0.20431270058825032, 0.035914341900278375, 0.11412779759421796], "isController": false}, {"data": ["Home Page-4", 24, 0, 0.0, 3.75, 2, 5, 4.0, 5.0, 5.0, 5.0, 0.20430922200750837, 30.545026773020968, 0.09896227940988687], "isController": false}, {"data": ["Home Page-1", 24, 0, 0.0, 2.083333333333333, 1, 6, 2.0, 3.0, 5.25, 6.0, 0.20431270058825032, 1.6576464028195153, 0.09756729549575625], "isController": false}, {"data": ["HIstory Page-1", 9, 0, 0.0, 2.2222222222222223, 1, 4, 2.0, 4.0, 4.0, 4.0, 0.08544330836489988, 0.3431082851528011, 0.041720365412548775], "isController": false}, {"data": ["Home Page-2", 24, 0, 0.0, 191.54166666666666, 165, 224, 187.5, 223.0, 223.75, 224.0, 0.20400357006247608, 18.0365851714905, 0.1049901185770751], "isController": false}, {"data": ["HIstory Page-0", 9, 0, 0.0, 2.7777777777777777, 2, 4, 3.0, 4.0, 4.0, 4.0, 0.0854424971993848, 0.14643709236808627, 0.04163652939696584], "isController": false}, {"data": ["Home Page-0", 24, 0, 0.0, 3.5416666666666665, 1, 10, 3.0, 7.0, 9.75, 10.0, 0.20430748276155614, 1.4233687324423256, 0.09776432280582277], "isController": false}, {"data": ["Login", 3, 0, 0.0, 6.333333333333333, 6, 7, 6.0, 7.0, 7.0, 7.0, 0.03663540445486518, 0.02107251291398007, 0.018496586038247362], "isController": false}, {"data": ["Visit Login-0", 27, 0, 0.0, 1.4814814814814812, 1, 3, 1.0, 3.0, 3.0, 3.0, 0.25038485078917594, 1.1049698639807481, 0.1215246785568559], "isController": false}, {"data": ["Verify Token", 3, 0, 0.0, 4.0, 4, 4, 4.0, 4.0, 4.0, 4.0, 0.03663674665689687, 0.01016097270562374, 0.02808578723209379], "isController": false}, {"data": ["Visit Login-5", 27, 0, 0.0, 156.25925925925927, 132, 241, 153.0, 172.39999999999998, 217.39999999999986, 241.0, 0.2501690957777016, 22.84649722729252, 0.12874913425278198], "isController": false}, {"data": ["Login Page", 3, 0, 0.0, 2.0, 2, 2, 2.0, 2.0, 2.0, 2.0, 0.03663764151289035, 0.006475989368977688, 0.020716010191370614], "isController": false}, {"data": ["Visit Login-6", 27, 0, 0.0, 2.185185185185185, 1, 7, 2.0, 3.0, 5.3999999999999915, 7.0, 0.25049170594129216, 0.3273026392084462, 0.12010881603239693], "isController": false}, {"data": ["Visit Login-7", 27, 0, 0.0, 2.0370370370370376, 1, 5, 2.0, 3.3999999999999986, 5.0, 5.0, 0.2504986779236443, 0.07901471969661827, 0.12011215904346616], "isController": false}, {"data": ["Get S3 Weather ", 47, 2, 4.25531914893617, 8898.617021276592, 3038, 20838, 8588.0, 14494.000000000002, 15560.999999999996, 20838.0, 0.3095567410920108, 0.06406219126654811, 0.16233590817032206], "isController": false}, {"data": ["Visit Login-8", 27, 0, 0.0, 2.0740740740740735, 1, 6, 2.0, 3.3999999999999986, 5.599999999999998, 6.0, 0.25050565029411215, 1.4653602004509103, 0.12109403993709525], "isController": false}, {"data": ["Add user Db Details", 9, 0, 0.0, 6.0, 4, 10, 5.0, 10.0, 10.0, 10.0, 0.08553588230262595, 0.01850678703466104, 0.04702802903943205], "isController": false}, {"data": ["Visit Login-1", 27, 0, 0.0, 163.962962962963, 111, 749, 131.0, 205.99999999999983, 605.3999999999992, 749.0, 0.2502061884330606, 6.050939113019062, 0.13145598571971345], "isController": false}, {"data": ["Visit Login-2", 27, 0, 0.0, 188.44444444444446, 129, 772, 162.0, 223.1999999999999, 600.799999999999, 772.0, 0.2501760498128312, 3.1557851908518955, 0.13583777704681071], "isController": false}, {"data": ["Stored Image", 8, 0, 0.0, 3.5, 2, 6, 3.0, 6.0, 6.0, 6.0, 0.0761723399190669, 9.629301431206855, 0.03868126636515115], "isController": false}, {"data": ["Visit Login-3", 27, 0, 0.0, 2.1481481481481484, 1, 7, 2.0, 3.0, 5.3999999999999915, 7.0, 0.2504940298922876, 2.8285766285591025, 0.12133304572907679], "isController": false}, {"data": ["Visit Login-4", 27, 0, 0.0, 192.44444444444449, 124, 762, 141.0, 351.79999999999995, 610.3999999999992, 762.0, 0.2501134774110476, 19.31076331796371, 0.1316515276606979], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/INTERNAL SERVER ERROR", 2, 100.0, 0.3081664098613251], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 649, 2, "500/INTERNAL SERVER ERROR", 2, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Get S3 Weather ", 47, 2, "500/INTERNAL SERVER ERROR", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
