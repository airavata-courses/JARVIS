/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 97.9869993709373, "KoPercent": 2.0130006290626965};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9407632627385196, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9611111111111111, 500, 1500, "HIstory Page"], "isController": false}, {"data": [0.9831460674157303, 500, 1500, "History Details"], "isController": false}, {"data": [0.948170731707317, 500, 1500, "Visit Login"], "isController": false}, {"data": [0.9939024390243902, 500, 1500, "Registration Signup"], "isController": false}, {"data": [1.0, 500, 1500, "Add user history "], "isController": false}, {"data": [0.9927536231884058, 500, 1500, "Base Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-1"], "isController": false}, {"data": [0.9927536231884058, 500, 1500, "Base Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-3"], "isController": false}, {"data": [0.9927536231884058, 500, 1500, "Base Page-4"], "isController": false}, {"data": [0.9927536231884058, 500, 1500, "Base Page-5"], "isController": false}, {"data": [0.9927536231884058, 500, 1500, "Base Page-6"], "isController": false}, {"data": [1.0, 500, 1500, "S3  Weather Details"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-6"], "isController": false}, {"data": [0.9090909090909091, 500, 1500, "Home Page"], "isController": false}, {"data": [0.9855072463768116, 500, 1500, "Base Page"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-5"], "isController": false}, {"data": [0.9888888888888889, 500, 1500, "HIstory Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-2"], "isController": false}, {"data": [0.9722222222222222, 500, 1500, "HIstory Page-0"], "isController": false}, {"data": [0.916083916083916, 500, 1500, "Home Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Login"], "isController": false}, {"data": [0.9634146341463414, 500, 1500, "Visit Login-0"], "isController": false}, {"data": [1.0, 500, 1500, "Verify Token"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-5"], "isController": false}, {"data": [0.9926470588235294, 500, 1500, "Login Page"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-6"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-7"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-8"], "isController": false}, {"data": [0.0, 500, 1500, "Get S3 Weather "], "isController": false}, {"data": [1.0, 500, 1500, "Add user Db Details"], "isController": false}, {"data": [0.9969512195121951, 500, 1500, "Visit Login-1"], "isController": false}, {"data": [0.9969512195121951, 500, 1500, "Visit Login-2"], "isController": false}, {"data": [0.0, 500, 1500, "Stored Image"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-3"], "isController": false}, {"data": [0.9969512195121951, 500, 1500, "Visit Login-4"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4769, 96, 2.0130006290626965, 205.55022017194293, 0, 20132, 6.0, 199.0, 303.5, 4256.6, 14.250369033461027, 739.5786011624181, 11.912242778448446], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HIstory Page", 90, 0, 0.0, 178.0777777777778, 41, 4708, 54.0, 86.00000000000006, 795.2500000000025, 4708.0, 0.2935123976375513, 141.01866203800336, 1.073154703862297], "isController": false}, {"data": ["History Details", 89, 0, 0.0, 158.68539325842693, 15, 8106, 36.0, 137.0, 423.0, 8106.0, 0.29054488592032546, 0.048802461306929654, 0.20627551959382476], "isController": false}, {"data": ["Visit Login", 164, 0, 0.0, 346.24390243902445, 139, 6738, 177.0, 265.0, 747.25, 6082.799999999994, 0.5372592570752784, 122.76814872622055, 2.4449493534871074], "isController": false}, {"data": ["Registration Signup", 164, 0, 0.0, 53.44512195121952, 3, 7305, 5.0, 15.0, 23.25, 2693.8999999999596, 0.5386108438127079, 0.14780238975719817, 0.2756172677322841], "isController": false}, {"data": ["Add user history ", 89, 0, 0.0, 25.617977528089888, 7, 242, 11.0, 63.0, 108.0, 242.0, 0.2904206857843969, 0.06352952501533682, 0.18037847281140276], "isController": false}, {"data": ["Base Page-0", 69, 0, 0.0, 15.550724637681153, 1, 603, 3.0, 4.0, 9.0, 603.0, 0.2555394660336201, 0.5846962587077851, 0.12153097652184863], "isController": false}, {"data": ["Base Page-1", 69, 0, 0.0, 57.028985507246375, 34, 160, 43.0, 121.0, 135.5, 160.0, 0.2554978319712954, 0.2075919884766775, 0.14671164570226727], "isController": false}, {"data": ["Base Page-2", 69, 0, 0.0, 17.942028985507253, 1, 1083, 2.0, 3.0, 8.5, 1083.0, 0.25553757328188015, 0.34038403316062943, 0.1237760120584107], "isController": false}, {"data": ["Base Page-3", 69, 0, 0.0, 87.0, 50, 235, 70.0, 162.0, 178.0, 235.0, 0.2554808037648244, 23.331584809444642, 0.13148279646881098], "isController": false}, {"data": ["Base Page-4", 69, 0, 0.0, 17.797101449275367, 1, 1078, 2.0, 3.0, 4.5, 1078.0, 0.25553757328188015, 0.044918714053455495, 0.14423898179387376], "isController": false}, {"data": ["Base Page-5", 69, 0, 0.0, 17.69565217391305, 1, 1078, 2.0, 3.0, 3.0, 1078.0, 0.25555082313290495, 0.044671481778115224, 0.14399689936297477], "isController": false}, {"data": ["Base Page-6", 69, 0, 0.0, 18.173913043478265, 1, 1085, 2.0, 3.0, 9.5, 1085.0, 0.25553757328188015, 0.2081233751143438, 0.12352646364700262], "isController": false}, {"data": ["S3  Weather Details", 136, 0, 0.0, 24.669117647058826, 3, 498, 8.0, 33.3, 124.80000000000052, 418.819999999999, 0.45892766152735176, 0.09321968124774332, 0.3639152941017672], "isController": false}, {"data": ["HIstory Page-6", 90, 0, 0.0, 36.27777777777779, 26, 89, 33.5, 49.80000000000001, 57.0, 89.0, 0.29354207436399216, 0.06163236912915851, 0.16540407901174167], "isController": false}, {"data": ["Home Page", 143, 0, 0.0, 485.22377622377616, 172, 6568, 208.0, 844.3999999999992, 2437.3999999999987, 6035.600000000003, 0.45586406962287607, 115.41260878574388, 1.1565770047658517], "isController": false}, {"data": ["Base Page", 69, 0, 0.0, 117.69565217391305, 53, 1374, 73.0, 174.0, 214.0, 1374.0, 0.25546850702723517, 24.760486704530308, 0.9350546526739038], "isController": false}, {"data": ["HIstory Page-3", 90, 0, 0.0, 57.255555555555574, 38, 333, 50.0, 68.80000000000001, 79.70000000000002, 333.0, 0.2935248419857934, 47.24316729203765, 0.15306861876993524], "isController": false}, {"data": ["HIstory Page-2", 90, 0, 0.0, 3.8, 1, 95, 2.0, 4.0, 5.900000000000006, 95.0, 0.29356696914937336, 0.05160356879578829, 0.1657047931331424], "isController": false}, {"data": ["HIstory Page-5", 90, 0, 0.0, 7.511111111111111, 2, 135, 5.0, 8.900000000000006, 20.80000000000001, 135.0, 0.29356505401596994, 47.668485699712306, 0.14993605786167213], "isController": false}, {"data": ["HIstory Page-4", 90, 0, 0.0, 56.45555555555555, 3, 4547, 5.0, 7.0, 14.950000000000031, 4547.0, 0.29356409645863846, 44.33047203475799, 0.14936220142085022], "isController": false}, {"data": ["Home Page-3", 143, 0, 0.0, 4.587412587412586, 0, 203, 2.0, 7.0, 19.399999999999864, 124.6800000000004, 0.45621165668637204, 0.08019345527690133, 0.2575100952780498], "isController": false}, {"data": ["Home Page-4", 143, 0, 0.0, 7.300699300699302, 2, 44, 4.0, 17.599999999999994, 34.399999999999864, 44.0, 0.45621165668637204, 68.20542475139655, 0.22365063638335814], "isController": false}, {"data": ["Home Page-1", 143, 0, 0.0, 3.9440559440559455, 0, 34, 2.0, 7.599999999999994, 23.599999999999966, 30.04000000000002, 0.45621020124293354, 3.7013616718030193, 0.22053129845239464], "isController": false}, {"data": ["HIstory Page-1", 90, 0, 0.0, 4.577777777777778, 1, 111, 2.0, 4.0, 14.750000000000043, 111.0, 0.29356601157954826, 1.1788510152491234, 0.14506289244067522], "isController": false}, {"data": ["Home Page-2", 143, 0, 0.0, 213.041958041958, 168, 331, 204.0, 268.0, 287.0, 320.00000000000006, 0.4558684293579269, 40.3049369773851, 0.23461197487463617], "isController": false}, {"data": ["HIstory Page-0", 90, 0, 0.0, 70.32222222222222, 1, 2621, 3.0, 6.700000000000017, 249.55000000000058, 2621.0, 0.2935564362248642, 0.5031167437252312, 0.14477148466167622], "isController": false}, {"data": ["Home Page-0", 143, 0, 0.0, 271.5734265734265, 1, 6340, 3.0, 605.5999999999992, 2191.599999999998, 5805.840000000003, 0.45621020124293354, 3.1783238043623903, 0.22097681622704593], "isController": false}, {"data": ["Login", 68, 0, 0.0, 10.426470588235292, 4, 65, 7.0, 22.1, 30.099999999999994, 65.0, 0.2518238714216939, 0.14484791041736106, 0.12861707495463467], "isController": false}, {"data": ["Visit Login-0", 164, 0, 0.0, 155.609756097561, 1, 6545, 2.0, 5.5, 301.25, 5895.649999999994, 0.5378283540484702, 2.3734827460400747, 0.26418717000623093], "isController": false}, {"data": ["Verify Token", 68, 0, 0.0, 3.9705882352941178, 2, 11, 4.0, 5.100000000000001, 7.549999999999997, 11.0, 0.251840658933677, 0.06984643275113699, 0.1945370715005259], "isController": false}, {"data": ["Visit Login-5", 164, 0, 0.0, 172.07317073170742, 132, 330, 164.0, 207.0, 228.5, 293.5999999999997, 0.5376203089349872, 49.097754697621355, 0.2766854519616585], "isController": false}, {"data": ["Login Page", 68, 0, 0.0, 16.44117647058824, 1, 1010, 2.0, 2.0, 2.0, 1010.0, 0.25182853439496344, 0.04451266086473475, 0.14386688732524766], "isController": false}, {"data": ["Visit Login-6", 164, 0, 0.0, 2.396341463414635, 0, 22, 2.0, 3.5, 6.0, 19.399999999999977, 0.5379677284968722, 0.7029304889929835, 0.2611034776005327], "isController": false}, {"data": ["Visit Login-7", 164, 0, 0.0, 2.4573170731707323, 1, 18, 2.0, 4.0, 6.0, 14.749999999999972, 0.5379783168495466, 0.16969433236562842, 0.26110861667404744], "isController": false}, {"data": ["Visit Login-8", 164, 0, 0.0, 1.9756097560975616, 0, 8, 2.0, 3.0, 5.0, 6.699999999999989, 0.5379818463930613, 3.1469836522406616, 0.2632118213309802], "isController": false}, {"data": ["Get S3 Weather ", 143, 11, 7.6923076923076925, 3844.65034965035, 1, 20132, 3054.0, 5286.799999999999, 10203.999999999998, 17777.560000000012, 0.4519838297253645, 0.11068714580113344, 0.23967501908288374], "isController": false}, {"data": ["Add user Db Details", 89, 0, 0.0, 16.58426966292135, 4, 335, 9.0, 20.0, 54.0, 335.0, 0.29055342265402595, 0.06299107405194704, 0.16145009520521558], "isController": false}, {"data": ["Visit Login-1", 164, 0, 0.0, 141.5060975609756, 98, 671, 131.0, 165.5, 182.0, 549.4499999999989, 0.5376908146671563, 13.00403262988184, 0.28249771317473643], "isController": false}, {"data": ["Visit Login-2", 164, 0, 0.0, 177.37195121951225, 113, 645, 167.0, 203.0, 244.75, 498.0999999999987, 0.5376908146671563, 6.782570559624666, 0.29194930952630754], "isController": false}, {"data": ["Stored Image", 85, 85, 100.0, 82.74117647058824, 1, 5141, 2.0, 2.4000000000000057, 3.0, 5141.0, 0.2762089829660295, 0.19393970581306175, 0.14107158016722016], "isController": false}, {"data": ["Visit Login-3", 164, 0, 0.0, 2.2621951219512204, 0, 15, 2.0, 3.0, 5.75, 14.349999999999994, 0.5379641991386013, 6.074687533827779, 0.2637285429370877], "isController": false}, {"data": ["Visit Login-4", 164, 0, 0.0, 150.8231707317073, 110, 645, 139.0, 175.5, 220.5, 439.5999999999982, 0.5374018586239891, 41.49172689909297, 0.2828707048811817], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 11, 11.458333333333334, 0.23065632208010065], "isController": false}, {"data": ["404/Not Found", 85, 88.54166666666667, 1.782344306982596], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4769, 96, "404/Not Found", 85, "502/Bad Gateway", 11, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Get S3 Weather ", 143, 11, "502/Bad Gateway", 11, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Stored Image", 85, 85, "404/Not Found", 85, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
