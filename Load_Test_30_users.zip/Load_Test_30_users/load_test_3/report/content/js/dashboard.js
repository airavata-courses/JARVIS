/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.23173569101908, "KoPercent": 1.7682643089809214};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9363657515123314, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9358974358974359, 500, 1500, "HIstory Page"], "isController": false}, {"data": [1.0, 500, 1500, "History Details"], "isController": false}, {"data": [0.9503311258278145, 500, 1500, "Visit Login"], "isController": false}, {"data": [1.0, 500, 1500, "Registration Signup"], "isController": false}, {"data": [1.0, 500, 1500, "Add user history "], "isController": false}, {"data": [0.9636363636363636, 500, 1500, "Base Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "Base Page-6"], "isController": false}, {"data": [0.9924242424242424, 500, 1500, "S3  Weather Details"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-6"], "isController": false}, {"data": [0.8776978417266187, 500, 1500, "Home Page"], "isController": false}, {"data": [0.9636363636363636, 500, 1500, "Base Page"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-2"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-5"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-3"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-4"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "HIstory Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "Home Page-2"], "isController": false}, {"data": [0.9358974358974359, 500, 1500, "HIstory Page-0"], "isController": false}, {"data": [0.8776978417266187, 500, 1500, "Home Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "Login"], "isController": false}, {"data": [0.9536423841059603, 500, 1500, "Visit Login-0"], "isController": false}, {"data": [1.0, 500, 1500, "Verify Token"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-5"], "isController": false}, {"data": [1.0, 500, 1500, "Login Page"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-6"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-7"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-8"], "isController": false}, {"data": [0.0, 500, 1500, "Get S3 Weather "], "isController": false}, {"data": [1.0, 500, 1500, "Add user Db Details"], "isController": false}, {"data": [0.9966887417218543, 500, 1500, "Visit Login-1"], "isController": false}, {"data": [0.9966887417218543, 500, 1500, "Visit Login-2"], "isController": false}, {"data": [0.0, 500, 1500, "Stored Image"], "isController": false}, {"data": [1.0, 500, 1500, "Visit Login-3"], "isController": false}, {"data": [0.9933774834437086, 500, 1500, "Visit Login-4"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4298, 76, 1.7682643089809214, 408.20195439739365, 0, 27073, 5.0, 197.0, 353.09999999999945, 12751.910000000304, 12.783448735336808, 669.9735763244462, 10.685562931456266], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["HIstory Page", 78, 0, 0.0, 408.9230769230769, 41, 10231, 54.0, 212.5000000000001, 3787.15, 10231.0, 0.2403068533666066, 115.45594398424143, 0.8786219326216554], "isController": false}, {"data": ["History Details", 78, 0, 0.0, 19.102564102564106, 10, 82, 13.0, 41.300000000000026, 60.34999999999998, 82.0, 0.2406471557357324, 0.04042120193998631, 0.1708500802928491], "isController": false}, {"data": ["Visit Login", 151, 0, 0.0, 1134.2781456953642, 144, 23625, 173.0, 233.8, 7485.800000000097, 23132.03999999999, 0.4949083436302674, 113.0900997180907, 2.252219610661178], "isController": false}, {"data": ["Registration Signup", 151, 0, 0.0, 6.410596026490064, 3, 51, 5.0, 7.0, 13.400000000000034, 46.31999999999991, 0.49605781865965837, 0.1371133531126807, 0.2538420868922471], "isController": false}, {"data": ["Add user history ", 78, 0, 0.0, 24.782051282051285, 6, 288, 8.0, 94.40000000000003, 156.14999999999998, 288.0, 0.2404409316777845, 0.05257839183548908, 0.14933635990924896], "isController": false}, {"data": ["Base Page-0", 55, 0, 0.0, 358.92727272727274, 1, 11243, 3.0, 4.399999999999999, 1679.5999999999647, 11243.0, 0.19418915435919346, 0.44432147330428734, 0.09235363102824923], "isController": false}, {"data": ["Base Page-1", 55, 0, 0.0, 49.618181818181824, 31, 119, 45.0, 63.4, 108.79999999999995, 119.0, 0.1941541937305846, 0.15775028240609998, 0.11148697843123413], "isController": false}, {"data": ["Base Page-2", 55, 0, 0.0, 2.218181818181818, 0, 14, 2.0, 3.0, 5.599999999999987, 14.0, 0.19418092719627456, 0.2586550631794126, 0.09405638661069549], "isController": false}, {"data": ["Base Page-3", 55, 0, 0.0, 77.49090909090913, 51, 172, 67.0, 130.2, 157.6, 172.0, 0.19414322828419744, 17.729978648657234, 0.09991550908766803], "isController": false}, {"data": ["Base Page-4", 55, 0, 0.0, 2.1272727272727274, 1, 8, 2.0, 3.0, 4.799999999999983, 8.0, 0.19418983998757183, 0.03413493281031536, 0.10961106202423489], "isController": false}, {"data": ["Base Page-5", 55, 0, 0.0, 2.418181818181818, 1, 14, 2.0, 3.0, 8.0, 14.0, 0.19418092719627456, 0.03394373629700503, 0.10941640135961955], "isController": false}, {"data": ["Base Page-6", 55, 0, 0.0, 2.418181818181819, 1, 14, 2.0, 3.0, 5.599999999999987, 14.0, 0.19418092719627456, 0.1581512629704033, 0.09386675679898038], "isController": false}, {"data": ["S3  Weather Details", 132, 0, 0.0, 123.87121212121212, 3, 14949, 5.0, 10.0, 92.39999999999998, 10077.869999999815, 0.4188880426504189, 0.08508663366336633, 0.33216512757044936], "isController": false}, {"data": ["HIstory Page-6", 78, 0, 0.0, 39.025641025641036, 23, 112, 33.0, 68.30000000000003, 76.19999999999999, 112.0, 0.24031943999408445, 0.05045769492063297, 0.13541437194979172], "isController": false}, {"data": ["Home Page", 139, 0, 0.0, 1864.4532374100713, 171, 21487, 201.0, 9834.0, 14544.0, 21232.999999999996, 0.44150811549089986, 111.77829974708574, 1.1201543789505448], "isController": false}, {"data": ["Base Page", 55, 0, 0.0, 436.94545454545454, 56, 11320, 71.0, 154.2, 1822.3999999999648, 11320.0, 0.19414117240089093, 18.8165264437926, 0.7105870255454485], "isController": false}, {"data": ["HIstory Page-3", 78, 0, 0.0, 63.47435897435899, 39, 221, 50.0, 127.70000000000006, 171.64999999999992, 221.0, 0.24030981480739785, 38.67814630631491, 0.12531781358120161], "isController": false}, {"data": ["HIstory Page-2", 78, 0, 0.0, 2.4743589743589753, 0, 8, 2.0, 5.0, 5.049999999999997, 8.0, 0.24034313604654028, 0.04224781688318091, 0.1356624342137698], "isController": false}, {"data": ["HIstory Page-5", 78, 0, 0.0, 7.897435897435901, 3, 85, 5.0, 8.300000000000026, 24.14999999999999, 85.0, 0.24034387662347667, 39.026541099188066, 0.12275375729890457], "isController": false}, {"data": ["HIstory Page-4", 78, 0, 0.0, 8.525641025641026, 3, 90, 5.0, 9.100000000000009, 24.049999999999827, 90.0, 0.24033943323031604, 36.293132069599835, 0.12228207491503384], "isController": false}, {"data": ["Home Page-3", 139, 0, 0.0, 3.5539568345323733, 0, 69, 2.0, 6.0, 17.0, 50.19999999999973, 0.4417648984417458, 0.07765398605421314, 0.24935557744075107], "isController": false}, {"data": ["Home Page-4", 139, 0, 0.0, 11.230215827338126, 2, 92, 4.0, 54.0, 81.0, 91.19999999999999, 0.441760686477038, 66.04494825599873, 0.21656627403464168], "isController": false}, {"data": ["Home Page-1", 139, 0, 0.0, 2.956834532374101, 0, 43, 2.0, 6.0, 9.0, 32.99999999999986, 0.4417522627885691, 3.5840603508275706, 0.2135423535940837], "isController": false}, {"data": ["HIstory Page-1", 78, 0, 0.0, 2.897435897435897, 0, 13, 2.5, 5.0, 6.049999999999997, 13.0, 0.24034017378443334, 0.9651160103531151, 0.1187618436864485], "isController": false}, {"data": ["Home Page-2", 139, 0, 0.0, 208.45323741007184, 168, 355, 197.0, 258.0, 266.0, 353.0, 0.4415151274517589, 39.03614607321528, 0.2272250704756611], "isController": false}, {"data": ["HIstory Page-0", 78, 0, 0.0, 342.5897435897437, 1, 10145, 3.0, 5.300000000000026, 3722.3, 10145.0, 0.24034387662347667, 0.41191748386152494, 0.11852896259263253], "isController": false}, {"data": ["Home Page-0", 139, 0, 0.0, 1655.474820143885, 1, 21229, 3.0, 9597.0, 14278.0, 20973.799999999996, 0.441760686477038, 3.077656970046083, 0.21397783251231528], "isController": false}, {"data": ["Login", 55, 0, 0.0, 8.509090909090911, 4, 57, 7.0, 13.399999999999999, 21.599999999999987, 57.0, 0.19452775734253863, 0.11189145417456568, 0.09935353231459737], "isController": false}, {"data": ["Visit Login-0", 151, 0, 0.0, 947.8344370860926, 1, 23390, 2.0, 4.0, 6969.800000000098, 22869.99999999999, 0.49517288420168953, 2.1852404919017916, 0.2432343366732908], "isController": false}, {"data": ["Verify Token", 55, 0, 0.0, 4.036363636363637, 2, 24, 3.0, 5.399999999999999, 7.199999999999996, 24.0, 0.19453257359520956, 0.0539523934580464, 0.15026881417364332], "isController": false}, {"data": ["Visit Login-5", 151, 0, 0.0, 166.2119205298013, 133, 353, 159.0, 203.20000000000005, 212.0, 304.6399999999991, 0.4950478819491117, 45.20986106284485, 0.25477561893279477], "isController": false}, {"data": ["Login Page", 55, 0, 0.0, 1.8727272727272726, 0, 6, 2.0, 3.0, 3.1999999999999957, 6.0, 0.19452982142162392, 0.03438466570050189, 0.11113275930825195], "isController": false}, {"data": ["Visit Login-6", 151, 0, 0.0, 2.3973509933774837, 1, 19, 2.0, 3.0, 6.400000000000006, 17.95999999999998, 0.4952654590061236, 0.6471339688966732, 0.24037786438090178], "isController": false}, {"data": ["Visit Login-7", 151, 0, 0.0, 2.3178807947019875, 1, 12, 2.0, 3.0, 7.200000000000017, 12.0, 0.4952735812543869, 0.15622399096207712, 0.24038180652678742], "isController": false}, {"data": ["Visit Login-8", 151, 0, 0.0, 1.8675496688741724, 1, 19, 2.0, 2.0, 3.0, 11.719999999999857, 0.49527520573600853, 2.897166486678409, 0.24231726374388698], "isController": false}, {"data": ["Get S3 Weather ", 137, 5, 3.6496350364963503, 4581.189781021896, 3, 27073, 3008.0, 7436.6, 17853.699999999997, 27067.68, 0.4318047864142237, 0.09559615260359375, 0.22897460842082368], "isController": false}, {"data": ["Add user Db Details", 78, 0, 0.0, 7.192307692307692, 4, 37, 6.0, 11.100000000000009, 21.099999999999994, 37.0, 0.2406501255700014, 0.05216014340279277, 0.13372062641536211], "isController": false}, {"data": ["Visit Login-1", 151, 0, 0.0, 136.18543046357615, 98, 588, 129.0, 160.40000000000003, 192.60000000000005, 398.7199999999963, 0.4950722280873163, 11.973016258286723, 0.26010630733493767], "isController": false}, {"data": ["Visit Login-2", 151, 0, 0.0, 175.5364238410597, 125, 593, 167.0, 228.80000000000007, 237.0, 423.47999999999666, 0.49500568764813296, 6.244129362647395, 0.26877261946519715], "isController": false}, {"data": ["Stored Image", 71, 71, 100.0, 757.4647887323941, 1, 23579, 2.0, 9.199999999999989, 6183.199999999887, 23579.0, 0.24925924365617672, 0.17501698846561628, 0.1273072113595512], "isController": false}, {"data": ["Visit Login-3", 151, 0, 0.0, 2.052980132450331, 1, 16, 2.0, 3.0, 6.400000000000006, 12.359999999999928, 0.49526870787346045, 5.5925703800203355, 0.24279774546140348], "isController": false}, {"data": ["Visit Login-4", 151, 0, 0.0, 150.9205298013246, 109, 651, 137.0, 176.0, 233.40000000000015, 610.9599999999992, 0.4950770976023187, 38.22368588895027, 0.26059233946059546], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 4, 5.2631578947368425, 0.09306654257794322], "isController": false}, {"data": ["500/INTERNAL SERVER ERROR", 1, 1.3157894736842106, 0.023266635644485806], "isController": false}, {"data": ["404/Not Found", 71, 93.42105263157895, 1.6519311307584923], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4298, 76, "404/Not Found", 71, "502/Bad Gateway", 4, "500/INTERNAL SERVER ERROR", 1, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Get S3 Weather ", 137, 5, "502/Bad Gateway", 4, "500/INTERNAL SERVER ERROR", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Stored Image", 71, 71, "404/Not Found", 71, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
